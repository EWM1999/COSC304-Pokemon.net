<div class="container">
    <div class="masthead">
        <div class="navbar">
            <div class="navbar-inner">
                <div class="container">
                    <ul class="nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="admin.php">Admin Page</a></li>
                        <li><a href="listorder.php">All Orders</a></li>
                        <li><a href="listcust.php">All Customers</a></li>
                        <li><a href="dataManagement.php">Load Database</a></li>
                    </ul>
                </div>
        </div>
    </div><!-- /.navbar -->
</div>

