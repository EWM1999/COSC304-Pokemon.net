<div class="container">
    <div class="masthead">
        <div class="navbar">
          <div class="navbar-inner">
            <div class="container">
                <ul class="nav">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="listprod.php">Start Shopping</a></li>
                    <li><a href="aboutus.php">About Us</a></li>
                </ul>
            </div>
        </div>
    </div><!-- /.navbar -->
</div>

